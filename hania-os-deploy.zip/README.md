# Hania OS — haniafayyaz portfolio site

Static site. No build step, no dependencies. `index.html` + `src/` is the whole thing.

## Deploy on Vercel
1. Push this folder to a GitHub repo.
2. Vercel dashboard → Add New → Project → Import the repo.
3. Framework preset: Other. Build command: none. Output directory: root (default).
4. Deploy. Every `git push` after that redeploys automatically.

## Updating content
- Work projects + journal writings live in `index.html` (`PROJECTS` and `POSTS` near the bottom).
- Easiest path: open `yoursite/#admin` in the browser, edit visually, hit Email backup, and bake the JSON into `index.html`.
- New project images go in `src/` and are referenced as `src/filename.jpg`.

## Notes
- Fonts load from Google Fonts CDN. Everything else is local.
- Admin panel + guestbook fridge save per-browser (localStorage) until edits are baked into the code.
